-- this file is streamed in
insert into foo
