-- Make a new dir entry
-- and return its inode


INSERT INTO dir_entries(type)
                VALUES(:type)