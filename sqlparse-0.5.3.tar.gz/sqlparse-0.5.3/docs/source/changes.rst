.. _changes:

============================
 Changes in python-sqlparse
============================

Upcoming Deprecations
=====================

* ``sqlparse.SQLParseError`` is deprecated (version 0.1.5), use
  ``sqlparse.exceptions.SQLParseError`` instead.


Changelog
=========

.. include:: ../../CHANGELOG
